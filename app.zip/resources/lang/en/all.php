<?php

// resources/lang/fr/all.php

return [
    'login' => 'Login',
    'welcome' => 'Welcome to our application!',
    'home' => 'Home',
    'plans' => 'Plans',
    'account' => 'Account',
    'help' => 'Help',
    'contact' => 'Contact',
    'affiliate' => 'Affiliate',
    'remember' => 'Remember',
    'login to account' => 'Please Enter Login Details',
    'users' => 'Users'

];
