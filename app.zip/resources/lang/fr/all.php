<?php
// French Language Translation Here
// resources/lang/fr/all.php

return [
    'login' =>'Login',
    'welcome' => 'Welcome to our application!',
    'home' => 'Domicile',
    'plans' => 'Des plans',
    'account' => 'Compte',
    'help' => 'Aider',
    'contact' => 'Contacter',
    'affiliate' => 'Affilier',
    'remember' => 'Rappelles toi',
    'login to account' => 'Please Enter Login Details',
    'users' => 'Users'

];
