<?php $__env->startSection('title'); ?>
    All Purchases
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-sm-12 col-lg-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <div class="header-title">
                        <h4 class="card-title">Purchases</h4>
                    </div>
                </div>
                <div class="card-body">
                    <p>Here is the List of all your active Purchases.</p>
                    <table class="table basic-table">
                        <thead>
                            <tr>

                                <th scope="col" style="background: #393B87 !important;">User</th>
                                <th scope="col" style="background: #393B87 !important;">Plan Name</th>
                                <th scope="col" style="background: #393B87 !important;">Charged</th>
                                <th scope="col" style="background: #393B87 !important;">Status</th>
                                <th scope="col" style="background: #393B87 !important;">Purchased on</th>
                                <th scope="col" style="background: #393B87 !important;">Expires On</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php
                                        $user = DB::table('users')->select('fname','lname')->where('id',$purchase->user_id)->get();
                                    ?>
                                    <th scope="row"><?php echo e($user[0]->fname); ?> <?php echo e($user[0]->lname); ?></th>
                                    <th><?php echo e($purchase->plan); ?></th>
                                    <td><?php echo e($purchase->paid.env('CR')); ?></td>


                                    <?php if($purchase->status == "Active"): ?>
                                    <td><span class="badge badge-pill badge-danger"><?php echo e($purchase->status); ?></span></td>
                                    <?php else: ?>
                                    <td><span class="badge badge-pill badge-warning"><?php echo e($purchase->status); ?></span></td>
                                    <?php endif; ?>


                                    <td><?php echo e(date('d M Y h:i A',strtotime($purchase->created_at))); ?></td>
                                    <td><?php echo e(date('d M Y h:i A',strtotime($purchase->expiry))); ?> </td>

                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        </tbody>
                    </table>
                    <?php echo e($purchases->links()); ?>

                </div>

            </div>

        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\app\resources\views/admin/purchases.blade.php ENDPATH**/ ?>