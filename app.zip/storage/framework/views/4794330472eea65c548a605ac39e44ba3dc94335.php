<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo e('Oops - ' . config('app.name')); ?></title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(url('public/assets/images/favicon.ico')); ?>" />
    <link rel="stylesheet" href="<?php echo e(url('public/assets/css/backend-plugin.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/assets/css/backend.css?v=1.0.2')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/assets/vendor/@fortawesome/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet"
        href="<?php echo e(url('public/assets/vendor/line-awesome/dist/line-awesome/css/line-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/assets/vendor/remixicon/fonts/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/assets/vendor/@icon/dripicons/dripicons.css')); ?>">

    <link rel='stylesheet' href='<?php echo e(url('public/assets/vendor/fullcalendar/core/main.css')); ?>' />
    <link rel='stylesheet' href='<?php echo e(url('public/assets/vendor/fullcalendar/daygrid/main.css')); ?>' />
    <link rel='stylesheet' href='<?php echo e(url('public/assets/vendor/fullcalendar/timegrid/main.css')); ?>' />
    <link rel='stylesheet' href='<?php echo e(url('public/assets/vendor/fullcalendar/list/main.css')); ?>' />
    <link rel="stylesheet" href="<?php echo e(url('public/assets/vendor/mapbox/mapbox-gl.css')); ?>">
    <style>
        .premium {
            position: absolute;
            width: fit-content;
            color: white;
            padding: 4px;
            border-radius: 6px;
            z-index: 10;
            left: -2px;
            right: 0;
            background-color: orange;
            margin-top: -37px;
        }

        @media (min-width: 1px) and (max-width: 450px) {}

    </style>
</head>

<body class=" ">
    <!-- loader Start -->
    <div id="loading">
        <div id="loading-center">
        </div>
    </div>
    <!-- loader END -->

    <div class="wrapper">
        <div class="container">
            <div class="row no-gutters height-self-center">
                <div class="col-sm-12 text-center align-self-center">
                    <div class="iq-error position-relative">
                        <img src="<?php echo e(url('public/assets/images/error/404.png')); ?>" class="img-fluid iq-error-img"
                            alt="">
                        <h2 class="mb-0 mt-4">Oops! This Page is Not Found.</h2>
                        <p>The requested page dose not exist.</p>
                        <a class="btn btn-primary btn-lg d-inline-flex align-items-center mt-3"
                            href="<?php echo e(route('home')); ?>"><i class="ri-home-4-line"></i>Back to Home</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
        <script>
        window.setTimeout(function() {
            window.location.href = "<?php echo e(route('home')); ?>";
        }, 2500);
    </script>

    <!-- jQuery Load -->
    <script src="<?php echo e(url('public/assets/js/jquery.js')); ?>"></script>
    <!-- Backend Bundle JavaScript -->
    <script src="<?php echo e(url('public/assets/js/backend-bundle.min.js')); ?>"></script>

    <!-- Flextree Javascript-->

    <!-- Table Treeview JavaScript -->
    <script src="<?php echo e(url('public/assets/js/table-treeview.js')); ?>"></script>

    <!-- Masonary Gallery Javascript -->

    <!-- Mapbox Javascript -->

    <!-- Fullcalender Javascript -->
    <script src='<?php echo e(url('public/assets/vendor/fullcalendar/core/main.js')); ?>'></script>
    <script src='<?php echo e(url('public/assets/vendor/fullcalendar/daygrid/main.js')); ?>'></script>
    <script src='<?php echo e(url('public/assets/vendor/fullcalendar/timegrid/main.js')); ?>'></script>
    <script src='<?php echo e(url('public/assets/vendor/fullcalendar/list/main.js')); ?>'></script>

    <!-- SweetAlert JavaScript -->
    <script src="<?php echo e(url('public/assets/js/sweetalert.js')); ?>"></script>

    <!-- Vectoe Map JavaScript -->
    <script src="<?php echo e(url('public/assets/js/vector-map-custom.js')); ?>"></script>

    <!-- Chart Custom JavaScript -->

    <!-- Chart Custom JavaScript -->
    <script src="<?php echo e(url('public/assets/js/chart-custom.js')); ?>"></script>

    <!-- slider JavaScript -->
    <script src="<?php echo e(url('public/assets/js/slider.js')); ?>"></script>

    <!-- app JavaScript -->
    <script src="<?php echo e(url('public/assets/js/app.js')); ?>"></script>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\app\resources\views/errors/404.blade.php ENDPATH**/ ?>