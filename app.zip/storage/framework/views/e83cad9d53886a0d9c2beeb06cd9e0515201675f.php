<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title><?php echo $__env->yieldContent('title'); ?> - Admin Panel <?php echo e(config('app.name')); ?></title>

        <!-- Favicon -->
        <link rel="shortcut icon" href="<?php echo e(url('public/assets/images/favicon.ico')); ?>" />
        <link rel="stylesheet" href="<?php echo e(url('public/assets/css/backend-plugin.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('public/assets/css/backend.css?v=1.0.2')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('public/assets/vendor/@fortawesome/fontawesome-free/css/all.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('public/assets/vendor/line-awesome/dist/line-awesome/css/line-awesome.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('public/assets/vendor/remixicon/fonts/remixicon.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('public/assets/vendor/@icon/dripicons/dripicons.css')); ?>">

        <link rel='stylesheet' href='<?php echo e(url('public/assets/vendor/fullcalendar/core/main.css')); ?>' />
        <link rel='stylesheet' href='<?php echo e(url('public/assets/vendor/fullcalendar/daygrid/main.css')); ?>' />
        <link rel='stylesheet' href='<?php echo e(url('public/assets/vendor/fullcalendar/timegrid/main.css')); ?>' />
        <link rel='stylesheet' href='<?php echo e(url('public/assets/vendor/fullcalendar/list/main.css')); ?>' />
        <link rel="stylesheet" href="<?php echo e(url('public/assets/vendor/mapbox/mapbox-gl.css')); ?>">
        <style>

            .premium{
                position: absolute;
        width: fit-content;
        color: white;
        padding: 4px;
        border-radius: 6px;
        z-index: 10;
        left: -2px;
        right: 0;
        background-color: orange;
        margin-top: -37px;
                    }

            @media (min-width: 1px) and (max-width: 450px) {

                }
        </style>
    </head>

    <body class="email-chimp ">

            <?php echo $__env->make('admin.layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- loader Start -->
    <div id="loading">
        <div id="loading-center">
        </div>
    </div>
    <!-- loader END -->
        <!-- Wrapper Starts-->
                <div class="content-page">
                            <div class="container-fluid">
                                <?php echo $__env->yieldContent('content'); ?>
                            </div>
                </div>
        <!-- Wrapper End-->
                <footer class="iq-footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-6">
                                <ul class="list-inline mb-0">
                                    <li class="list-inline-item"><a href="<?php echo e(route('policy')); ?>">Privacy Policy</a></li>
                                    <li class="list-inline-item"><a href="<?php echo e(route('tos')); ?>">Terms of Use</a></li>
                                </ul>
                            </div>
                            <div class="col-lg-6 text-right">
                                Copyright &copy; 2021 <a href="<?php echo e(route('home')); ?>"><?php echo e(config('app.name')); ?></a>
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- jQuery Load -->
                <script src="<?php echo e(url('public/assets/js/jquery.js')); ?>"></script>
                <!-- Backend Bundle JavaScript -->
                <script src="<?php echo e(url('public/assets/js/backend-bundle.min.js')); ?>"></script>

                <!-- Flextree Javascript-->

                <!-- Table Treeview JavaScript -->
                <script src="<?php echo e(url('public/assets/js/table-treeview.js')); ?>"></script>

                <!-- Masonary Gallery Javascript -->

                <!-- Mapbox Javascript -->

                <!-- Fullcalender Javascript -->
                <script src='<?php echo e(url('public/assets/vendor/fullcalendar/core/main.js')); ?>'></script>
                <script src='<?php echo e(url('public/assets/vendor/fullcalendar/daygrid/main.js')); ?>'></script>
                <script src='<?php echo e(url('public/assets/vendor/fullcalendar/timegrid/main.js')); ?>'></script>
                <script src='<?php echo e(url('public/assets/vendor/fullcalendar/list/main.js')); ?>'></script>

                <!-- SweetAlert JavaScript -->
                <script src="<?php echo e(url('public/assets/js/sweetalert.js')); ?>"></script>

                <!-- Vectoe Map JavaScript -->
                <script src="<?php echo e(url('public/assets/js/vector-map-custom.js')); ?>"></script>

                <!-- Chart Custom JavaScript -->

                <!-- Chart Custom JavaScript -->
                <script src="<?php echo e(url('public/assets/js/chart-custom.js')); ?>"></script>

                <!-- slider JavaScript -->
                <script src="<?php echo e(url('public/assets/js/slider.js')); ?>"></script>

                <!-- app JavaScript -->
                <script src="<?php echo e(url('public/assets/js/app.js')); ?>"></script>
            </body>

            </html>
<?php /**PATH D:\xampp\htdocs\app\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>