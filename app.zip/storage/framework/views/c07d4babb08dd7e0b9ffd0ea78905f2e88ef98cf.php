<?php $__env->startSection('title'); ?>
    Admin Panel
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-block card-stretch card-height">
                <a href="<?php echo e(route('users')); ?>">
                <div class="card-body">
                    <i class="las la-home" style="font-size:72px"></i>
                    <br>
                    <h2 class="mb-3">Total Users</h2>
                    <h1 class="mb-0"><?php echo e(App\Models\User::count()); ?></h1>
                </div>
                </a>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-block card-stretch card-height">
                <a href="<?php echo e(route('adminpurchases')); ?>">
                <div class="card-body">
                    <i class="las la-credit-card" style="font-size:72px"></i>
                    <br>
                    <h2 class="mb-3">Active Subs.</h2>
                    <h1 class="mb-0"><?php echo e(count($purchases)); ?></h1>
                </div>
                </a>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-block card-stretch card-height">
                <a href="<?php echo e(route('adminpurchases')); ?>">
                <div class="card-body">
                    <i class="las la-calendar" style="font-size:72px"></i>
                    <br>
                    <h2 class="mb-3">Expired Subs.</h2>
                    <h1 class="mb-0"><?php echo e(count($epurchases)); ?></h1>
                </div>
                </a>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-block card-stretch card-height">
                <div class="card-body">
                    <i class="las la-wallet" style="font-size:72px"></i>
                    <br>
                    <h2 class="mb-3">Paid Users</h2>
                    <h1 class="mb-0"><?php echo e(App\Models\User::where('membership','Premium')->count()); ?></h1>
                </div>
            </div>
        </div>
        
        
        <div class="col-lg-5 col-md-6">
            <div class="card card-block card-stretch card-height">
                <div class="card-header">
                    <div class="header-title">
                        <h4 class="card-title">Recent Registrations</h4>
                    </div>
                </div>
                <div class="card-body">
                    <ul class="list-inline p-0 m-0">
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="d-flex align-items-center mb-3">
                                    <span class="bg-info-light rounded-small iq-card-icon-small mr-3"><?php echo e($user->id); ?></span>
                                    <p class="mb-0 font-size-16"><b><?php echo e($user->fname); ?></b> joined on <?php echo e(date('l h:i A',strtotime($user->created_at))); ?></p>
                                </li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                </div>
            </div>
        </div>
        <div class="col-lg-7 col-md-6">
            <div class="row">
                <div class="col-md-12 col-lg-12">
                    <div class="card card-block card-stretch card-height">
                        <div class="card-header">
                            <div class="header-title">
                                <h4 class="card-title">Recent Tickets</h4>
                            </div>
                        </div>
                        <div class="card-body">
                            <ul class="list-inline p-0 m-0">
                                <li class="mb-3 d-flex">
                                    <span><i class="lab la-facebook-f text-primary font-size-20 mr-3"></i></span>
                                    <p class="mb-0 font-size-16 line-height"><?php echo e(Auth::user()->facebook); ?></p>
                                </li>
                                <li class="mb-3 d-flex">
                                    <span><i class="lab la-twitter text-info font-size-20 mr-3"></i></span>
                                    <p class="mb-0 font-size-16 line-height"><?php echo e(Auth::user()->twitter); ?></p>
                                </li>
                                <li class=" d-flex">
                                    <span><i class="lab la-instagram  text-danger font-size-20 mr-3"></i></span>
                                    <p class="mb-0 font-size-16 line-height"><?php echo e(Auth::user()->instagram); ?></p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="card card-block card-stretch card-height">
                        <div class="card-header">
                            <div class="header-title">
                                <h4 class="card-title">Expired Subscriptions</h4>
                            </div>
                        </div>
                        <div class="card-body">
                            <ul class="list-inline mb-0 p-0">




                                <?php $__currentLoopData = $epurchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="d-flex align-items-center mb-3">
                                    <span class="bg-info-light rounded-small iq-card-icon-small mr-3"><?php echo e($purchase->id); ?></span>
                                    <p class="mb-0 font-size-16"><?php echo e($purchase->plan); ?> Plan Expired on <?php echo e(date('d M Y h:i A',strtotime($purchase->expiry))); ?></p>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\app\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>