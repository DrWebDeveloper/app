<?php $__env->startSection('title'); ?>
    Account
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <div class="header-title">
                        <h4 class="card-title">Account Setting</h4>
                    </div>
                </div>
                <div class="card-body">
                    <div class="acc-edit">
                        <form>
                            <div class="row">
                            <div class="col-lg-6">
                            <div class="form-group">
                                <label for="name">Name:</label>
                                
                                <div class="form-control"><?php echo e(Auth::user()->fname." ".Auth::user()->lname); ?> </div>
                            </div>
                            </div>
                            <div class="col-lg-6">
                            <div class="form-group">
                                <label for="email">Email Id:</label>
                                
                                <div class="form-control"><?php echo e(Auth::user()->email); ?> </div>
                            </div>
                            </div>
                            <div class="col-lg-6">
                            <div class="form-group">
                                <label for="phone">Phone:</label>
                                
                                <div class="form-control"><?php echo e(Auth::user()->phone); ?> </div>
                            </div>
                            </div>
                            
                            
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\app\resources\views/user/account.blade.php ENDPATH**/ ?>