<?php $__env->startSection('title'); ?>
    Plans
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


         <div class="row">
            <div class="col-sm-12">
               <div class="card">
                  <div class="card-body">
                     <div class="table-responsive pricing pt-2">
                        <table id="my-table" class="table">
                           <thead>
                              <tr>
                                 <th class="text-center prc-wrap"></th>
                                 <th class="text-center prc-wrap">
                                    <div class="prc-box">
                                       <div class="h3 pt-4 text-white"><?php echo e($plans[0]->price.env('CR')); ?><small> / Per Month</small>
                                       </div> <span class="type text-white "><?php echo e($plans[0]->name); ?></span>
                                    </div>
                                 </th>
                                 <th class="text-center prc-wrap">
                                    <div class="prc-box active">
                                       <div class="h3 pt-4 text-white"><?php echo e($plans[1]->price.env('CR')); ?><small> / Per Month</small>
                                       </div> <span class="type text-white "><?php echo e($plans[1]->name); ?></span>
                                    </div>
                                 </th>
                                 <th class="text-center prc-wrap">
                                    <div class="prc-box">
                                       <div class="h3 pt-4 text-white"><?php echo e($plans[2]->price.env('CR')); ?><small> / Per Year</small>
                                       </div> <span class="type text-white "><?php echo e($plans[2]->name); ?></span>
                                    </div>
                                 </th>
                                 
                              </tr>
                           </thead>
                           <tbody>
                              <tr>
                                 <th class="text-center" scope="row">Form Builder</th>
                                 <td class="text-center child-cell"><i class="ri-check-line ri-2x"></i>
                                 </td>
                                 <td class="text-center child-cell active"><i class="ri-check-line ri-2x"></i>
                                 </td>
                                 <td class="text-center child-cell"><i class="ri-check-line ri-2x"></i>
                                 </td>
                                 
                              </tr>
                              <tr>
                                 <th class="text-center" scope="row">Appointment Manager</th>
                                                                  <td class="text-center child-cell"><i class="ri-check-line ri-2x"></i>
                                 </td>
                                 <td class="text-center child-cell active"><i class="ri-check-line ri-2x"></i>
                                 </td>
                                 <td class="text-center child-cell"><i class="ri-check-line ri-2x"></i>
                                 </td>
                                 
                              </tr>
                              <tr>
                                 <th class="text-center" scope="row">Copyrighting Tool</th>
                                 <td class="text-center child-cell"><i class="ri-check-line ri-2x"></i>
                                 </td>
                                 <td class="text-center child-cell active"><i class="ri-check-line ri-2x"></i>
                                 </td>
                                 <td class="text-center child-cell"><i class="ri-check-line ri-2x"></i>
                                 </td>
                                 
                              </tr>
                              <tr>
                                 <th class="text-center" scope="row">Mailing & SMS</th>
                                 <td class="text-center child-cell"><i class="ri-close-line i_close"></i>
                                 </td>
                                 <td class="text-center child-cell active"><i class="ri-check-line ri-2x"></i>
                                 </td>
                                 <td class="text-center child-cell"><i class="ri-check-line ri-2x"></i>
                                 </td>
                                 
                              </tr>
                              <tr>
                                 <th class="text-center" scope="row">Digital Desktop</th>
                                 <td class="text-center child-cell"><i class="ri-close-line i_close"></i>
                                 </td>
                                 <td class="text-center child-cell active"><i class="ri-check-line ri-2x"></i>
                                 </td>
                                 <td class="text-center child-cell"><i class="ri-check-line ri-2x"></i>
                                 </td>
                                 
                              </tr>


                              <tr>
                                 <td class="text-center">
                                     
                                 </td>
                                 <?php if(auth()->guard()->check()): ?>
                                 <td class="text-center"> <a href="<?php echo e(route('home')); ?>" class="btn btn-primary btn-lg mt-3 disabled">Already Subscribed</a>
                                 <?php endif; ?>
                                 <?php if(auth()->guard()->guest()): ?>
                                     <td class="text-center"> <a href="<?php echo e(route('subscribe',['pid'=>1])); ?>" class="btn btn-primary btn-lg mt-3">Purchase</a>
                                 <?php endif; ?>
                                 </td>
                                 <td class="text-center"> <a href="<?php echo e(route('subscribe',['pid'=>2])); ?>" class="btn btn-primary btn-lg mt-3">Purchase</a>
                                 </td>
                                 <td class="text-center"> <a href="<?php echo e(route('subscribe',['pid'=>3])); ?>" class="btn btn-primary btn-lg mt-3">Purchase</a>
                                 </td>
                                 
                              </tr>
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
         </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\app\resources\views/plan/plans.blade.php ENDPATH**/ ?>