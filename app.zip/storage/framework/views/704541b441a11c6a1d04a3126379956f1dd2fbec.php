<?php $__env->startSection('title'); ?>
    Purchasing Plan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-6">
                    <div class="or-detail rounded">
                        <div class="p-3">
                            <h5 class="mb-3">Purchase Details</h5>
                            <div class="mb-2">
                                <h6>Plan Name</h6>
                                <p><?php echo e($plan->name); ?></p>
                            </div>
                            <div class="mb-2">
                                <h6>Price</h6>
                                <p><?php echo e($plan->price . env('CR', 'production')); ?></p>
                            </div>
                            <div class="mb-2">
                                <h6>Next Due Date</h6>
                                <p><?php echo e(date('l d M Y', $date)); ?></p>
                            </div>
                            <div class="mb-2">
                                <h6>Sub Total</h6>
                                <p><?php echo e($plan->price . env('CR', 'production')); ?></p>
                            </div>

                        </div>
                        
                        
                    </div>
                </div>

                
                <div class="col-sm-12 col-md-12 col-lg-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <div class="row text-center">
                                <h3 class="panel-heading">Payment Details</h3>
                            </div>
                        </div>
                        <div class="panel-body">
                            <?php if(Session::has('success')): ?>
                                <div class="alert alert-success text-center">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                    <?php echo e(Session::get('success')); ?>

                                </div>
                                 <script>
        window.setTimeout(function() {
            window.location.href = "<?php echo e(route('purchases')); ?>";
        }, 2500);
    </script>
                            <?php endif; ?>
                            <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>" />
                            <script src="https://js.stripe.com/v3/"></script>
                            <script>
                                var stripe = Stripe('<?php echo e(env('STRIPE_KEY')); ?>');
                                var elements = stripe.elements();

                            </script>
                            <form action="<?php echo e(route('pay')); ?>" method="post" id="payment-form">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="pid" value="<?php echo e($plan->id); ?>">
                                <div class="form-row">
                                    <label for="card-element">
                                        Please fill your card details
                                    </label>
                                    <div id="card-element" style="width: -webkit-fill-available;padding:15px 4px 11px 0px;">
                                        <!-- A Stripe Element will be inserted here. -->
                                    </div>

                                    <!-- Used to display Element errors. -->
                                    <div id="card-errors" role="alert"></div>
                                </div>

                                <button class="btn btn-danger">Pay Now (<?php echo e($plan->price.env('CR')); ?>)</button>
                            </form>
                            <script src="<?php echo e(url('public/assets/js/card.js')); ?>"></script>

                        </div>
                    </div>
                </div>


                </body>

            </div>
        </div>
    </div>
    </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\app\resources\views/plan/subscribe.blade.php ENDPATH**/ ?>