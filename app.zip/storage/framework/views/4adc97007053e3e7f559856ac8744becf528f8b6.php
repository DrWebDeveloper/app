<?php $__env->startSection('title'); ?>
    Promotion Banner
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<br>
    <div class="row">
      <div class="col-lg-12">
         <div class="tab-content">
            <div id="pills-1" class="tab-pane fade active show">
               <div class="card">
                  <div class="card-body pb-0">
                     <div class="row">

                                 <?php if(Session::has('success')): ?>
                                 <div class="col-lg-12 col-md-12 col-sm-12 mb-0">
                                <div class="alert alert-success text-center">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                    <?php echo e(Session::get('success')); ?>

                                </div>
                                </div>
                            <?php endif; ?>

                        <div class="col-lg-3 col-md-6 col-sm-6 mb-0">

                            <h3>Active Banner</h3>
                           <div class="forms-box">
                              <div class="bg-info-light image-box text-center
                                 p-2">
                                 <img src="<?php echo e(url('/public/images/'.$setting->banner)); ?>" class="d-block w-100" alt="image">
                              </div>
                              <div class="forms-text d-flex flex-wrap
                                 justify-content-between text-left">
                                 <div>
                                    <h5 class="mb-3"><i class="las la-file-alt
                                          text-dark mr-3"></i> Banner</h5>
                                    
                                 </div>
                                 <div class="dropdown">
                                    <span class="dropdown-toggle1" id="dropdownMenuButton-ten" data-toggle="dropdown" aria-expanded="false" role="button">
                                       <i class="fas fa-cog mt-2"></i>
                                    </span>
                                    <div class="dropdown-menu
                                       dropdown-menu-right" aria-labelledby="dropdownMenuButton-ten" style="">
                                       <a class="dropdown-item copy" href="#"><i class="far fa-copy mr-2"></i>Copy</a>
                                       <a href="#" class="dropdown-item edit-note1" data-toggle="modal" data-target="#edit-note1"><i class="las la-pen mr-3"></i>Edit</a>
                                       <a class="dropdown-item" data-extra-toggle="delete" data-closest-elem=".item" href="#"><i class="ri-delete-bin-6-fill mr-2"></i>Delete</a>
                                    </div>
                                 </div>
                              </div>
                              <form action="<?php echo e(route('editbanner')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">

                                    <div class="col-12">
                                        <input type="file" name="image" class="form-control">
                                    </div>

                                    <div class="col-12">
                                        <button type="submit" class="btn btn-danger btn-block">Upload</button>
                                    </div>

                                </div>
                            </form>
                           </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6 mb-0">
                            <h3>Previous Banners</h3>
<div class="row">
                            <?php $__currentLoopData = File::glob(public_path('images').'/*'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $path): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="card">
                            <img src="<?php echo e(url('public'.str_replace(public_path(), '', $path))); ?>" class="card-img-top" alt="#">
                            <div class="card-body">
                            
                            <p class="card-text">Statude: Inactive</p>
                            </div>
                            </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
                        </div>

                     </div>
                  </div>
               </div>
            </div>

         </div>
      </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\app\resources\views/admin/banner.blade.php ENDPATH**/ ?>