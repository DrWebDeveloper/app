<?php $__env->startSection('title'); ?>
    Help Guides
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<br>
    <div class="row">
      <div class="col-lg-12">
         <div class="tab-content">
            <div id="pills-1" class="tab-pane fade active show">
               <div class="card">
                  <div class="card-body pb-0">
                     <div class="row">

                                 <?php if(Session::has('success')): ?>
                                 <div class="col-lg-12 col-md-12 col-sm-12 mb-0">
                                <div class="alert alert-success text-center">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                    <?php echo e(Session::get('success')); ?>

                                </div>
                                </div>
                            <?php endif; ?>

                        
                            <h3>Help Guides</h3>

                            <?php $__currentLoopData = $guides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-6">
                            <div class="card">
                            <?php echo e($guide->title); ?>

                            <div class="card-body">
<div class="embed-responsive embed-responsive-4by3">
                                        {<?php echo $guide->code; ?>}
                                    </div>
                            </div>
                            </div>
                        </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        

                     </div>
                  </div>
               </div>
            </div>

         </div>
      </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\app\resources\views/admin/help.blade.php ENDPATH**/ ?>